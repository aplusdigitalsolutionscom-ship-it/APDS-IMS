import React, { Suspense, lazy, useCallback, useEffect, useState } from 'react';
import Swal from 'sweetalert2';

import { useNavigate, useLocation, Routes, Route } from 'react-router-dom';
import {
  LayoutDashboard,
  Printer,
  Barcode,
  Bell,
  Truck,
  Loader2,
  RotateCcw,
  AlertOctagon,
  FileText,
  Receipt,
  Package, Tags, Ruler, Link2, Layers,
  Wrench,
  Users as UsersIcon,
  History,
  User,
  ChevronDown,
  ChevronRight,
  ShoppingCart,
  ArrowDownCircle,
  ArrowUpCircle,
  BarChart3,
  Warehouse,
  ChevronLeft as HideIcon,
  ChevronRight as ShowIcon
} from 'lucide-react';
import { printerService } from '../services/api';
import NotificationPanel from './NotificationPanel';

const Dashboard = lazy(() => import('./Dashboard'));
const Models = lazy(() => import('./Models'));
const Serials = lazy(() => import('./Serials'));
const GodownMaster = lazy(() => import('./GodownMaster'));
const CategoryMaster = lazy(() => import('./CategoryMaster'));
const BrandMaster = lazy(() => import('./BrandMaster'));
const CategoryBrandMapping = lazy(() => import('./CategoryBrandMapping'));
const ItemMaster = lazy(() => import('./ItemMaster'));
const ItemVariant = lazy(() => import('./ItemVariant'));
const StockIn = lazy(() => import('./StockIn'));
const StockOut = lazy(() => import('./StockOut'));
const CurrentStock = lazy(() => import('./CurrentStock'));
const ComboMaster = lazy(() => import('./ComboMaster'));
const UnitMaster = lazy(() => import('./UnitMaster'));
const VariantBarcode = lazy(() => import('./VariantBarcode'));
const VendorMaster = lazy(() => import('./VendorMaster'));
const VendorDetails = lazy(() => import('./VendorDetails'));
const Users = lazy(() => import('./Users'));
const ProfilePage = lazy(() => import('./ProfilePage'));
const UserActivity = lazy(() => import('./UserActivity'));
const Dispatch = lazy(() => import('./Dispatch'));
const NewDispatch = lazy(() => import('./NewDispatch'));
const Returns = lazy(() => import('./Returns'));
const Damaged = lazy(() => import('./Damaged'));
const Reports = lazy(() => import('./Reports'));
const Billing = lazy(() => import('./Billing'));
const OrderTracking = lazy(() => import('./OrderTracking'));
const Installations = lazy(() => import('./Installations'));
const FbfFbaManagement = lazy(() => import('./FbfFbaManagement'));
const FbfFbaMaster = lazy(() => import('./FbfFbaMaster'));
const Notifications = lazy(() => import('./Notifications'));

const tabContentFallback = (
  <div className="flex justify-center items-center min-h-[320px]">
    <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-6 flex items-center gap-3">
      <Loader2 className="animate-spin text-indigo-600" size={22} />
      <span className="text-sm font-semibold text-slate-600">Loading section...</span>
    </div>
  </div>
);

const getReturnsArray = (payload) => {
  if (Array.isArray(payload)) return payload;
  if (payload && Array.isArray(payload.data)) return payload.data;
  if (payload && Array.isArray(payload.returns)) return payload.returns;
  if (payload && Array.isArray(payload.results)) return payload.results;
  return [];
};

export default function AdminLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const activeTab = location.pathname.split('/')[1] || 'dashboard';

  const [models, setModels] = useState([]);
  const [serials, setSerials] = useState([]);
  const [dispatches, setDispatches] = useState([]);
  const [returns, setReturns] = useState([]);
  const [orders, setOrders] = useState([]);
  const [orderTrackingFocusId, setOrderTrackingFocusId] = useState(null);
  const [installations, setInstallations] = useState([]);
  const [installationStats, setInstallationStats] = useState(null);
  const [expandedMenus, setExpandedMenus] = useState({
    printer: true,
    stationery: true,
    fba: true
  });
  const [isSidebarVisible, setIsSidebarVisible] = useState(true);

  const toggleSubmenu = (menu) => {
    setExpandedMenus(prev => ({ ...prev, [menu]: !prev[menu] }));
  };

  const [isLoading, setIsLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);
  const [notification, setNotification] = useState(null);
  const [dataStatus, setDataStatus] = useState({
    models: false,
    serials: false,
    dispatches: false,
    returns: false,
    orders: false,
    installations: false,
    installationStats: false
  });

  const userRole = currentUser?.role || 'User';
  const isAdmin = userRole === 'Admin';
  const isSupervisor = userRole === 'Supervisor';
  const isAccountant = userRole === 'Accountant';
  const isUser = userRole === 'User' || userRole === 'Operator';

  const showNotification = (message, type = 'success') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 3000);
  };

  const markDataLoaded = useCallback((nextStatus) => {
    setDataStatus((prev) => ({ ...prev, ...nextStatus }));
  }, []);

  const loadCoreData = useCallback(async () => {
    const results = await Promise.allSettled([
      printerService.getModels(),
      printerService.getSerials(),
      printerService.getDispatches(true),
      printerService.getReturns()
    ]);

    let hasFailure = false;
    const loadedKeys = {};

    if (results[0].status === 'fulfilled') {
      setModels(Array.isArray(results[0].value) ? results[0].value : []);
      loadedKeys.models = true;
    } else {
      hasFailure = true;
      console.error('Failed to load models:', results[0].reason);
    }

    if (results[1].status === 'fulfilled') {
      setSerials(Array.isArray(results[1].value) ? results[1].value : []);
      loadedKeys.serials = true;
    } else {
      hasFailure = true;
      console.error('Failed to load serials:', results[1].reason);
    }

    if (results[2].status === 'fulfilled') {
      setDispatches(Array.isArray(results[2].value) ? results[2].value : []);
      loadedKeys.dispatches = true;
    } else {
      hasFailure = true;
      console.error('Failed to load dispatches:', results[2].reason);
    }

    if (results[3].status === 'fulfilled') {
      setReturns(getReturnsArray(results[3].value));
      loadedKeys.returns = true;
    } else {
      hasFailure = true;
      console.error('Failed to load returns:', results[3].reason);
    }

    markDataLoaded(loadedKeys);
    return !hasFailure;
  }, [markDataLoaded]);

  const loadOrdersData = useCallback(async () => {
    try {
      const data = await printerService.getOrders();
      setOrders(Array.isArray(data) ? data : []);
      markDataLoaded({ orders: true });
      return true;
    } catch (error) {
      console.error('Failed to load orders:', error);
      return false;
    }
  }, [markDataLoaded]);

  const loadInstallationData = useCallback(async () => {
    const results = await Promise.allSettled([
      printerService.getInstallations(),
      printerService.getInstallationStats()
    ]);

    let hasFailure = false;
    const loadedKeys = {};

    if (results[0].status === 'fulfilled') {
      setInstallations(Array.isArray(results[0].value) ? results[0].value : []);
      loadedKeys.installations = true;
    } else {
      hasFailure = true;
      console.error('Failed to load installations:', results[0].reason);
    }

    if (results[1].status === 'fulfilled') {
      setInstallationStats(results[1].value || null);
      loadedKeys.installationStats = true;
    } else {
      hasFailure = true;
      console.error('Failed to load installation stats:', results[1].reason);
    }

    markDataLoaded(loadedKeys);
    return !hasFailure;
  }, [markDataLoaded]);

  const refreshData = useCallback(
    async ({
      includeOrders = dataStatus.orders || activeTab === 'orderTracking',
      includeInstallations =
      dataStatus.installations ||
      dataStatus.installationStats ||
      activeTab === 'installations'
    } = {}) => {
      const tasks = [loadCoreData()];

      if (includeOrders) {
        tasks.push(loadOrdersData());
      }

      if (includeInstallations) {
        tasks.push(loadInstallationData());
      }

      await Promise.all(tasks);
    },
    [
      activeTab,
      dataStatus.installationStats,
      dataStatus.installations,
      dataStatus.orders,
      loadCoreData,
      loadInstallationData,
      loadOrdersData
    ]
  );

  const handleUpdateDispatch = async (ids, updatedData) => {
    try {
      await printerService.updateDispatch(ids, updatedData);
      await refreshData();
      showNotification('Updated Successfully! ✅', 'success');
    } catch (error) {
      console.error(error);
      showNotification('Failed to update ❌', 'error');
    }
  };

  const handleDeleteDispatch = async (ids, reason) => {
    try {
      const result = await printerService.deleteDispatch(
        ids,
        reason,
        currentUser?.username || 'Unknown'
      );
      await refreshData();

      const successCount = result.results?.success?.length || ids.length;
      const failedCount = result.results?.failed?.length || 0;

      if (failedCount > 0) {
        showNotification(`Cancelled ${successCount} items. ${failedCount} failed.`, 'warning');
      } else {
        showNotification(`✅ Cancelled ${successCount} dispatch(es).`, 'success');
      }
    } catch (error) {
      console.error(error);
      showNotification('Failed to cancel ❌', 'error');
    }
  };

  const handleRestoreDispatch = async (ids) => {
    try {
      const result = await printerService.restoreDispatch(ids);
      await refreshData();

      const successCount = result.results?.success?.length || ids.length;
      if (result.results?.failed?.length > 0) {
        showNotification(`Restored ${successCount}. Some failed.`, 'warning');
      } else {
        showNotification(`✅ Restored ${successCount} dispatch(es)!`, 'success');
      }
    } catch (error) {
      console.error(error);
      showNotification('Failed to restore ❌', 'error');
    }
  };

  const handlePermanentDelete = async (ids) => {
    if (!isAdmin) {
      showNotification('🚫 Admin access required', 'error');
      return;
    }

    const result = await Swal.fire({
      title: "Are you sure?",
      text: "⚠️ PERMANENT DELETE: This cannot be undone. Continue?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#EF4444",
      cancelButtonColor: "#6B7280",
      confirmButtonText: "Yes, delete permanently!",
      cancelButtonText: "No, cancel"
    });

    if (!result.isConfirmed) return;

    try {
      await printerService.permanentDeleteDispatch(ids);
      await refreshData();
      Swal.fire({
        title: "Deleted!",
        text: "The dispatch records have been permanently deleted.",
        icon: "success",
        confirmButtonColor: "#6366F1",
      });
    } catch (error) {
      console.error(error);
      showNotification('Failed to delete ❌', 'error');
    }
  };

  useEffect(() => {
    const userStr = localStorage.getItem('pt_user');
    if (!userStr) {
      navigate('/login');
      return;
    }

    try {
      setCurrentUser(JSON.parse(userStr));
    } catch (error) {
      console.error('Failed to parse current user:', error);
      localStorage.removeItem('pt_user');
      navigate('/login');
      return;
    }

    const init = async () => {
      const coreLoaded = await loadCoreData();
      if (!coreLoaded) {
        showNotification('Some dashboard data could not be loaded. You can still keep working.', 'warning');
      }
      setIsLoading(false);
    };

    init();
  }, [loadCoreData, navigate]);

  useEffect(() => {
    if (activeTab === 'orderTracking' && !dataStatus.orders) {
      loadOrdersData();
    }

    if (
      activeTab === 'installations' &&
      (!dataStatus.installations || !dataStatus.installationStats)
    ) {
      loadInstallationData();
    }
  }, [
    activeTab,
    dataStatus.installationStats,
    dataStatus.installations,
    dataStatus.orders,
    loadInstallationData,
    loadOrdersData
  ]);

  const handleLogout = () => {
    localStorage.removeItem('pt_user');
    navigate('/login');
  };

  const handleOpenOrderDetails = useCallback((orderId) => {
    if (orderId === null || orderId === undefined || String(orderId).trim() === '') return;
    setOrderTrackingFocusId(String(orderId).trim());
    navigate('/orderTracking');
  }, [navigate]);

  const pendingInstallationsCount = installations.filter(
    (item) => item.installationStatus === 'Pending' || item.installationStatus === 'Scheduled'
  ).length;

  const allNavItems = [
    { id: 'dashboard', icon: LayoutDashboard, label: 'Dashboard', permission: 'dashboard', roles: ['Admin', 'Supervisor', 'Accountant', 'User', 'Operator'] },
    { id: 'categoryMaster', icon: Tags, label: 'Category Master', permission: 'stat_category', roles: ['Admin', 'Accountant', 'Operator', 'Supervisor'] },
    { id: 'brandMaster', icon: Barcode, label: 'Brand Master', permission: 'stat_brand', roles: ['Admin', 'Accountant', 'Operator', 'Supervisor'] },
    { id: 'vendorMaster', icon: UsersIcon, label: 'Vendor Master', permission: 'stat_vendor', roles: ['Admin', 'Accountant', 'Operator', 'Supervisor'] },
    { id: 'categoryBrandMapping', icon: FileText, label: 'Cate-Brand Mapping', permission: 'stat_mapping', roles: ['Admin', 'Accountant', 'Operator'] },
    { id: 'unitMaster', icon: Ruler, label: 'Unit Master', permission: 'stat_unit', roles: ['Admin', 'Accountant'] },
    { id: 'itemMaster', icon: Package, label: 'Item Master', permission: 'stat_item', roles: ['Admin', 'Accountant', 'Operator', 'Supervisor'] },
    { id: 'comboMaster', icon: Layers, label: 'Combos Master', permission: 'stat_combo', roles: ['Admin', 'Accountant', 'Operator', 'Supervisor'] },
    { id: 'currentStock', icon: Package, label: 'Current Stock', permission: 'stat_current_stock', roles: ['Admin', 'Accountant', 'Operator', 'Supervisor'] },
    { id: 'variantBarcode', icon: Barcode, label: 'Variant Barcode', permission: 'stat_item', roles: ['Admin', 'Operator', 'Supervisor'], hidden: true },
    { id: 'vendorDetails', icon: FileText, label: 'Vendor Details', permission: 'stat_vendor', roles: ['Admin', 'Accountant'], hidden: true },
    { id: 'stockIn', icon: Truck, label: 'Stock In', permission: 'stat_stock_in', roles: ['Admin', 'Accountant', 'Operator', 'Supervisor'] },
    { id: 'stockOut', icon: Receipt, label: 'Stock Out', permission: 'stat_stock_out', roles: ['Admin', 'Accountant', 'Operator', 'Supervisor'] },
    { id: 'models', icon: Printer, label: 'Models', permission: 'print_models', roles: ['Admin', 'Supervisor', 'User', 'Operator'] },
    { id: 'serials', icon: Barcode, label: 'Serials', permission: 'print_serials', roles: ['Admin', 'Supervisor', 'User', 'Operator'] },
    { id: 'godownMaster', icon: Warehouse, label: 'Godown Master', permission: 'godownMaster', roles: ['Admin', 'Supervisor', 'User', 'Operator'] },
    { id: 'orderTracking', icon: Package, label: 'Order Processing', permission: 'orders', roles: ['Admin', 'Supervisor', 'User', 'Operator'] },
    { id: 'billing', icon: Receipt, label: 'Billing', permission: 'billing', roles: ['Admin', 'Accountant'] },
    { id: 'dispatch', icon: Truck, label: ' Dispatch', permission: 'dispatch', roles: ['Admin', 'Supervisor', 'User', 'Operator'] },
    { id: 'installations', icon: Wrench, label: 'Installations', badge: pendingInstallationsCount > 0 ? pendingInstallationsCount : null, badgeColor: 'orange', permission: 'installation', roles: ['Admin', 'Supervisor', 'User', 'Operator'] },
    { id: 'returns', icon: RotateCcw, label: 'Returns', permission: 'returns', roles: ['Admin', 'Supervisor', 'User', 'Operator'] },
    { id: 'damaged', icon: AlertOctagon, label: 'Damaged', permission: 'damage', roles: ['Admin', 'Supervisor', 'User', 'Operator'] },
    { id: 'notifications', icon: Bell, label: 'Notifications', permission: 'notifications', roles: ['Admin', 'Supervisor', 'Accountant', 'User', 'Operator'] },
    { id: 'fbfFbaMaster', icon: Layers, label: 'FBF / FBA Master', permission: 'fbfFbaMaster', roles: ['Admin'] },
    { id: 'fbfFbaManagement', icon: Package, label: 'FBF / FBA Stock', permission: 'fbfFbaManagement', roles: ['Admin', 'Supervisor', 'Operator'] },
    { id: 'users', icon: UsersIcon, label: 'User Management', permission: 'users', roles: ['Admin'] },
    { id: 'activity', icon: History, label: 'User Activity', permission: 'users', roles: ['Admin'] },
    { id: 'reports', icon: FileText, label: 'Reports', permission: 'reports', roles: ['Admin', 'Supervisor', 'Accountant'] },
    { id: 'profile', icon: User, label: 'Profile', permission: null, roles: ['Admin', 'Supervisor', 'Accountant', 'User', 'Operator'], hidden: true }
  ];

  // ✅ NEW PERMISSION HELPER
  const hasPermission = useCallback((permissionId) => {
    if (!permissionId) return true; // Like Profile
    if (isAdmin) return true; // Admin has full access
    if (currentUser?.permissions && Array.isArray(currentUser.permissions)) {
      return currentUser.permissions.includes(permissionId);
    }
    // Fallback if permissions array is missing (Role based)
    const item = allNavItems.find(i => i.permission === permissionId);
    return item ? item.roles.includes(userRole) : false;
  }, [currentUser, isAdmin, userRole]);

  const canViewNotifications = hasPermission('notifications');
  
  const navItems = allNavItems.filter((item) => {
    if (item.hidden) return false;
    return hasPermission(item.permission);
  });

  const catalogLoaded = dataStatus.models && dataStatus.serials;
  const returnsLoaded = dataStatus.returns;
  const installationsLoaded = dataStatus.installations && dataStatus.installationStats;

  if (!currentUser) return null;

  return (
    <div className="flex h-screen bg-slate-50 relative">
      {notification && (
        <div
          className={`fixed top-5 right-5 px-4 py-3 rounded-lg shadow-lg text-sm font-medium z-50 transition-all transform animate-in slide-in-from-right duration-300 ${notification.type === 'success'
            ? 'bg-green-100 text-green-800 border-green-200'
            : notification.type === 'warning'
              ? 'bg-amber-100 text-amber-800 border-amber-200'
              : 'bg-red-100 text-red-800 border-red-200'
            }`}
        >
          {notification.message}
        </div>
      )}

      {/* Sidebar Toggle Button */}
      {!isSidebarVisible && (
        <button
          onClick={() => setIsSidebarVisible(true)}
          className="fixed top-1/2 left-0 z-[60] p-1.5 bg-indigo-600 text-white rounded-r-xl shadow-lg hover:bg-indigo-700 transition-all hover:scale-110 active:scale-95 md:flex hidden items-center justify-center -translate-y-1/2"
          title="Show Menu"
        >
          <ShowIcon size={20} />
        </button>
      )}

      <aside className={`bg-white border-r flex flex-col hidden md:flex print:hidden transition-all duration-300 ease-in-out ${isSidebarVisible ? 'w-70 opacity-100' : 'w-0 opacity-0 overflow-hidden border-none'}`}>
        <div className="p-4 flex items-center justify-between border-b border-slate-100">
          <div className="flex flex-col items-center justify-center flex-1">
            <img
              src="/aplus.png"
              alt="Company Logo"
              className="h-12 w-auto object-contain mb-[-35px]"
            />
          </div>
          <button
            onClick={() => setIsSidebarVisible(false)}
            className="p-1 hover:bg-slate-100 rounded-full text-slate-400 hover:text-slate-600 transition-colors border border-slate-200 shadow-sm flex items-center justify-center bg-white"
            title="Hide Menu"
          >
            <HideIcon size={18} />
          </button>
        </div>
        <div className="p-4 font-bold text-indigo-600 text-lg flex items-center gap-2">
          Inventory Management
        </div>
        <div className="px-4 py-2 text-xs text-slate-400 uppercase">Menu</div>
        <nav className="flex-1 px-2 space-y-1 overflow-y-auto">
          {/* 1. Dashboard */}
          {navItems.find(i => i.id === 'dashboard') && (
            <button
              onClick={() => navigate('/')}
              className={`w-full flex gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors relative whitespace-nowrap overflow-hidden ${activeTab === 'dashboard' ? 'bg-indigo-50 text-indigo-600' : 'text-slate-600 hover:bg-slate-100'}`}
            >
              <LayoutDashboard size={18} />
              <span>Dashboard</span>
            </button>
          )}

          {navItems.some(item => ['models', 'serials', 'godownMaster', 'orderTracking', 'billing', 'dispatch', 'installations', 'damaged'].includes(item.id)) && (
            <div className="space-y-1">
              <button
                onClick={() => toggleSubmenu('printer')}
                className="w-full flex items-center justify-between px-3 py-2 text-xs font-bold text-slate-400 uppercase tracking-wider hover:text-indigo-600 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <Printer size={16} />
                  <span>Serialized</span>
                </div>
                {expandedMenus.printer ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
              </button>
              {expandedMenus.printer && (
                <div className="space-y-1 ml-4 border-l border-slate-100 animate-in slide-in-from-top-1 duration-200">
                  {navItems.filter(item => ['models', 'serials', 'godownMaster', 'orderTracking', 'billing', 'dispatch', 'installations', 'damaged'].includes(item.id)).map(item => (
                    <button key={item.id} onClick={() => navigate(`/${item.id === 'dashboard' ? '' : item.id}`)} className={`w-full flex gap-3 pl-4 pr-3 py-2 rounded-lg text-sm font-medium transition-colors ${activeTab === item.id ? 'bg-indigo-50 text-indigo-600' : 'text-slate-600 hover:bg-slate-100'}`}>
                      {item.icon && <item.icon size={14} />} <span>{item.label}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {navItems.some(item => item.permission?.startsWith('stat_')) && (
            <div className="space-y-1">
              <button
                onClick={() => toggleSubmenu('stationery')}
                className="w-full flex items-center justify-between px-3 py-2 text-xs font-bold text-slate-400 uppercase tracking-wider hover:text-indigo-600 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <FileText size={16} />
                  <span>Non-Serialized</span>
                </div>
                {expandedMenus.stationery ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
              </button>
              {expandedMenus.stationery && (
                <div className="space-y-1 ml-4 border-l border-slate-100 animate-in slide-in-from-top-1 duration-200">
                  {navItems.filter(item => item.permission?.startsWith('stat_')).map(item => (
                    <button key={item.id} onClick={() => navigate(`/${item.id === 'dashboard' ? '' : item.id}`)} className={`w-full flex gap-3 pl-4 pr-3 py-2 rounded-lg text-sm font-medium transition-colors ${activeTab === item.id ? 'bg-indigo-50 text-indigo-600' : 'text-slate-600 hover:bg-slate-100'}`}>
                      {item.icon && <item.icon size={14} />} <span>{item.label}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {navItems.some(item => ['fbfFbaMaster', 'fbfFbaManagement'].includes(item.id)) && (
            <div className="space-y-1">
              <button
                onClick={() => toggleSubmenu('fba')}
                className="w-full flex items-center justify-between px-3 py-2 text-xs font-bold text-slate-400 uppercase tracking-wider hover:text-indigo-600 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <Package size={16} />
                  <span>FBF / FBA</span>
                </div>
                {expandedMenus.fba ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
              </button>
              {expandedMenus.fba && (
                <div className="space-y-1 ml-4 border-l border-slate-100 animate-in slide-in-from-top-1 duration-200">
                  {navItems.filter(item => ['fbfFbaMaster', 'fbfFbaManagement'].includes(item.id)).map(item => (
                    <button key={item.id} onClick={() => navigate(`/${item.id === 'dashboard' ? '' : item.id}`)} className={`w-full flex gap-3 pl-4 pr-3 py-2 rounded-lg text-sm font-medium transition-colors ${activeTab === item.id ? 'bg-indigo-50 text-indigo-600' : 'text-slate-600 hover:bg-slate-100'}`}>
                      {item.icon && <item.icon size={14} />} <span>{item.label}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {navItems.find(i => i.id === 'returns') && (
            <button onClick={() => navigate('/returns')} className={`w-full flex gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors relative ${activeTab === 'returns' ? 'bg-indigo-50 text-indigo-600' : 'text-slate-600 hover:bg-slate-100'}`}>
              <RotateCcw size={18} /> <span>Returns</span>
            </button>
          )}

          {navItems.find(i => i.id === 'notifications') && (
            <button onClick={() => navigate('/notifications')} className={`w-full flex gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors relative ${activeTab === 'notifications' ? 'bg-indigo-50 text-indigo-600' : 'text-slate-600 hover:bg-slate-100'}`}>
              <Bell size={18} /> <span>Notifications</span>
            </button>
          )}

          {/* Admin Items */}
          {navItems.find(i => i.id === 'users') && (
            <button onClick={() => navigate('/users')} className={`w-full flex gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors relative ${activeTab === 'users' ? 'bg-indigo-50 text-indigo-600' : 'text-slate-600 hover:bg-slate-100'}`}>
              <UsersIcon size={18} /> <span>User Management</span>
            </button>
          )}
          {navItems.find(i => i.id === 'activity') && (
            <button onClick={() => navigate('/activity')} className={`w-full flex gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors relative ${activeTab === 'activity' ? 'bg-indigo-50 text-indigo-600' : 'text-slate-600 hover:bg-slate-100'}`}>
              <History size={18} /> <span>User Activity</span>
            </button>
          )}

          {navItems.find(i => i.id === 'reports') && (
            <button onClick={() => navigate('/reports')} className={`w-full flex gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors relative ${activeTab === 'reports' ? 'bg-indigo-50 text-indigo-600' : 'text-slate-600 hover:bg-slate-100'}`}>
              <BarChart3 size={18} /> <span>Reports</span>
            </button>
          )}
        </nav>

        <div className="p-4 border-t border-slate-100">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-8 h-8 rounded-full bg-indigo-100 flex-shrink-0 flex items-center justify-center text-indigo-600 font-bold">
                {((currentUser?.fullName || currentUser?.username)?.[0] || 'U').toUpperCase()}
              </div>
              <div className="text-sm overflow-hidden min-w-0">
                <p className="font-semibold text-slate-700 whitespace-nowrap overflow-hidden text-ellipsis" title={currentUser.fullName || currentUser.username}>
                  {currentUser.fullName || currentUser.username?.split('@')[0] || 'User'}
                </p>
                <p className={`text-xs whitespace-nowrap ${isAdmin ? 'text-indigo-500 font-medium' : 'text-slate-400'}`}>
                  {currentUser.role || 'User'}
                  {isAdmin && ' ⭐'}
                </p>
              </div>
            </div>
          </div>
            <div className="flex items-center gap-2 mt-2 px-2">
              <button
                onClick={() => navigate('/profile')}
                className="flex-1 text-center text-indigo-600 text-xs hover:bg-indigo-50 py-2 rounded-lg transition font-semibold"
              >
                My Profile
              </button>
              {canViewNotifications && (
                <Suspense fallback={<div className="w-8 h-8"></div>}>
                  <NotificationPanel currentUser={currentUser} placement="top" onOpenOrderFromNotification={handleOpenOrderDetails} />
                </Suspense>
              )}
            </div>
          <button
            onClick={handleLogout}
            className="w-full text-center text-red-600 text-xs hover:bg-red-50 py-2 rounded transition"
          >
            Log Out
          </button>
        </div>
      </aside>

      <div className="md:hidden fixed top-0 left-0 right-0 bg-white border-b z-40 px-4 py-3 flex justify-between items-center print:hidden">
        <span className="font-bold text-indigo-600">PrintTrack</span>
        <div className="flex items-center gap-2">
          {canViewNotifications && (
            <Suspense fallback={<div className="w-8 h-8"></div>}>
              <NotificationPanel currentUser={currentUser} />
            </Suspense>
          )}
          <div className="flex gap-1">
          {navItems.slice(0, 5).map((item) => {
            const Icon = item.icon;
            const isInstallationTab = item.id === 'installations';

            return (
              <button
                key={item.id}
                onClick={() => navigate(`/${item.id === 'dashboard' ? '' : item.id}`)}
                className={`p-2 rounded relative ${activeTab === item.id
                  ? isInstallationTab
                    ? 'bg-orange-100 text-orange-600'
                    : 'bg-indigo-100 text-indigo-600'
                  : 'text-slate-500'
                  }`}
              >
                <Icon size={18} />
                {item.id === 'installations' && pendingInstallationsCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-orange-500 text-white text-[8px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                    {pendingInstallationsCount > 9 ? '9+' : pendingInstallationsCount}
                  </span>
                )}
              </button>
            );
          })}
          </div>
        </div>
      </div>

      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t z-40 px-2 py-2 flex justify-around items-center print:hidden">
        {navItems.slice(5, 9).map((item) => {
          const Icon = item.icon;
          const isInstallationTab = item.id === 'installations';

          return (
            <button
              key={item.id}
              onClick={() => navigate(`/${item.id === 'dashboard' ? '' : item.id}`)}
              className={`p-2 rounded flex flex-col items-center relative ${activeTab === item.id
                ? isInstallationTab
                  ? 'text-orange-600'
                  : 'text-indigo-600'
                : 'text-slate-500'
                }`}
            >
              <Icon size={18} />
              <span className="text-[10px] mt-0.5">{item.label}</span>
              {item.badge && item.badge > 0 && (
                <span className="absolute -top-1 right-0 bg-orange-500 text-white text-[8px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  {item.badge > 9 ? '9+' : item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      <main className="flex-1 p-4 md:p-6 overflow-auto md:mt-0 mt-14 mb-16 md:mb-0 print:p-0 print:m-0 print:overflow-visible">
        {isLoading ? (
          <div className="flex justify-center items-center h-full">
            <Loader2 className="animate-spin text-indigo-600" size={32} />
          </div>
        ) : (
          <div className="max-w-full mx-auto print:max-w-none">
            <Suspense fallback={tabContentFallback}>
              <Routes>
                {/* Routes modified to pass `hasPermission` prop to all child components */}
                <Route path="/" element={hasPermission('dashboard') ? <Dashboard models={models} serials={serials} dispatches={dispatches} returns={returns} onNavigate={(tab) => navigate(`/${tab === 'dashboard' ? '' : tab}`)} isAdmin={isAdmin} isAccountant={isAccountant} isSupervisor={isSupervisor} hasPermission={hasPermission} /> : <div />} />
                <Route path="/categoryMaster" element={hasPermission('stat_category') ? <CategoryMaster hasPermission={hasPermission} /> : <div />} />
                <Route path="/itemMaster" element={hasPermission('stat_item') ? <ItemMaster hasPermission={hasPermission} /> : <div />} />
                <Route path="/itemVariant" element={hasPermission('stat_item') ? <ItemVariant hasPermission={hasPermission} /> : <div />} />
                <Route path="/brandMaster" element={hasPermission('stat_brand') ? <BrandMaster hasPermission={hasPermission} /> : <div />} />
                <Route path="/categoryBrandMapping" element={hasPermission('stat_mapping') ? <CategoryBrandMapping hasPermission={hasPermission} /> : <div />} />
                <Route path="/unitMaster" element={hasPermission('stat_unit') ? <UnitMaster hasPermission={hasPermission} /> : <div />} />
                <Route path="/variantBarcode" element={hasPermission('stat_item') ? <VariantBarcode hasPermission={hasPermission} /> : <div />} />
                <Route path="/comboMaster" element={hasPermission('stat_combo') ? <ComboMaster hasPermission={hasPermission} /> : <div />} />
                <Route path="/vendorMaster" element={hasPermission('stat_vendor') ? <VendorMaster hasPermission={hasPermission} /> : <div />} />
                <Route path="/vendorDetails" element={hasPermission('stat_vendor') ? <VendorDetails hasPermission={hasPermission} /> : <div />} />
                <Route path="/stockIn" element={hasPermission('stat_stock_in') ? <StockIn hasPermission={hasPermission} /> : <div />} />
                <Route path="/stockOut" element={hasPermission('stat_stock_out') ? <StockOut hasPermission={hasPermission} /> : <div />} />
                <Route path="/currentStock" element={hasPermission('stat_current_stock') ? <CurrentStock hasPermission={hasPermission} /> : <div />} />
                <Route path="/notifications" element={hasPermission('notifications') ? <Notifications onOpenOrder={handleOpenOrderDetails} hasPermission={hasPermission} /> : <div />} />
                
                <Route path="/models" element={hasPermission('print_models') ? <Models models={models} serials={serials} onRefresh={refreshData} isAdmin={isAdmin} isUser={isUser} currentUser={currentUser} hasPermission={hasPermission} /> : <div />} />
                <Route path="/serials" element={hasPermission('print_serials') ? <Serials models={models} serials={serials} onRefresh={refreshData} isAdmin={isAdmin} isUser={isUser} currentUser={currentUser} hasPermission={hasPermission} /> : <div />} />
                <Route path="/godownMaster" element={hasPermission('godownMaster') ? <GodownMaster isAdmin={isAdmin} isUser={isUser} currentUser={currentUser} hasPermission={hasPermission} /> : <div />} />
                <Route path="/dispatch" element={hasPermission('dispatch') ? <Dispatch models={models} serials={serials} companies={[]} dispatches={dispatches} onNew={() => navigate('/newDispatch')} onUpdate={handleUpdateDispatch} onDelete={handleDeleteDispatch} onRestore={handleRestoreDispatch} onPermanentDelete={handlePermanentDelete} onRefresh={refreshData} isAdmin={isAdmin} isSupervisor={isSupervisor} isAccountant={isAccountant} currentUser={currentUser} hasPermission={hasPermission} /> : <div />} />
                <Route path="/newDispatch" element={hasPermission('dispatch') ? <NewDispatch models={models} serials={serials} companies={[]} currentUser={currentUser} onRefresh={refreshData} onBack={() => navigate('/dispatch')} hasPermission={hasPermission} /> : <div />} />
                <Route path="/billing" element={hasPermission('billing') ? <Billing models={models} serials={serials} dispatches={dispatches} onUpdate={handleUpdateDispatch} onRefresh={refreshData} isAdmin={isAdmin} hasPermission={hasPermission} currentUser={currentUser} /> : <div />} />
                <Route path="/orderTracking" element={hasPermission('orders') ? <OrderTracking orders={orders} models={models} serials={serials} returns={returns} currentUser={currentUser} onRefresh={refreshData} isAdmin={isAdmin} isSupervisor={isSupervisor} focusOrderId={orderTrackingFocusId} onFocusHandled={() => setOrderTrackingFocusId(null)} catalogLoaded={catalogLoaded} returnsLoaded={returnsLoaded} hasPermission={hasPermission} /> : <div />} />
                <Route path="/installations" element={hasPermission('installation') ? <Installations installations={installations} stats={installationStats} isLoaded={installationsLoaded} onRefresh={refreshData} isSupervisor={isSupervisor} hasPermission={hasPermission} currentUser={currentUser} /> : <div />} />
                <Route path="/returns" element={hasPermission('returns') ? <Returns returns={returns} isLoaded={returnsLoaded} onRefresh={refreshData} isAdmin={isAdmin} isSupervisor={isSupervisor} currentUser={currentUser} onOpenOrderDetails={handleOpenOrderDetails} hasPermission={hasPermission} /> : <div />} />
                <Route path="/damaged" element={hasPermission('damage') ? <Damaged returns={returns} isAdmin={isAdmin} isUser={isUser} onRefresh={refreshData} hasPermission={hasPermission} currentUser={currentUser} /> : <div />} />
                <Route path="/fbfFbaMaster" element={hasPermission('fbfFbaMaster') ? <FbfFbaMaster isAdmin={isAdmin} isUser={isUser} hasPermission={hasPermission} /> : <div />} />
                <Route path="/fbfFbaManagement" element={hasPermission('fbfFbaManagement') ? <FbfFbaManagement isAdmin={isAdmin} isUser={isUser} currentUser={currentUser} hasPermission={hasPermission} /> : <div />} />
                <Route path="/reports" element={hasPermission('reports') ? <Reports isAdmin={isAdmin} isAccountant={isAccountant} returns={returns} hasPermission={hasPermission} /> : <div />} />
                <Route path="/users" element={hasPermission('users') ? <Users currentUser={currentUser} hasPermission={hasPermission} /> : <div />} />
                <Route path="/profile" element={<ProfilePage currentUser={currentUser} hasPermission={hasPermission} />} />
                <Route path="/activity" element={hasPermission('users') ? <UserActivity hasPermission={hasPermission} /> : <div />} />
              </Routes>
            </Suspense>
          </div>
        )}
      </main>
    </div>
  );
}