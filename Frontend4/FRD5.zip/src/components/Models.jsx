import React, { useState, useMemo, useCallback } from "react";
import Swal from 'sweetalert2';
import { printerService } from "../services/api";
import { 
  Layers, Plus, Box, Trash2, CheckSquare, X, Search, Info, 
  Package, Tag, Building2, TrendingUp, History, Hash, Sparkles,
  Edit, Palette, Settings2, Loader2, Check, AlertTriangle, RefreshCw
} from "lucide-react";
import { format } from "date-fns";
import MasterDropdown from "./MasterDropdown";

// ✅ Toast Component
function Toast({ message, type, onClose }) {
  React.useEffect(() => {
    const timer = setTimeout(onClose, 4000);
    return () => clearTimeout(timer);
  }, [onClose]);

  const config = {
    success: { bg: "bg-emerald-500", icon: Check },
    error: { bg: "bg-red-500", icon: AlertTriangle },
    info: { bg: "bg-blue-500", icon: Info }
  };

  const { bg, icon: Icon } = config[type] || config.info;

  return (
    <div className={`fixed bottom-6 right-6 z-[100] ${bg} text-white px-5 py-3 rounded-xl shadow-2xl flex items-center gap-3 animate-in slide-in-from-bottom-5 duration-300`}>
      <Icon size={18} />
      <span className="font-medium text-sm">{message}</span>
      <button onClick={onClose} className="ml-2 hover:bg-white/20 rounded-full p-1 transition">
        <X size={14} />
      </button>
    </div>
  );
}

export default function Models({ models = [], serials = [], onRefresh, isAdmin, isUser, currentUser }) {
  const canManage = currentUser?.role === 'Admin' || 
                    !!currentUser?.allow_edit_models;

  const initialFormState = {
    name: "", 
    company: "HP", 
    mainCategory: "Printer",
    category: "Laser", 
    colorType: "Monochrome",
    printerType: "Multi-Function",
    description: "", 
    mrp: "",
    cpu: "",
    ram: "",
    ssd: ""
  };

  const [newModel, setNewModel] = useState(initialFormState);
  const [editingId, setEditingId] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSelectionMode, setIsSelectionMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [viewingModel, setViewingModel] = useState(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [toast, setToast] = useState(null);

  const showToast = useCallback((message, type = "info") => {
    setToast({ message, type });
  }, []);

  const isDuplicateModel = useCallback((name, excludeId = null) => {
    if (!name || !name.trim()) return false;
    const trimmedName = name.trim().toLowerCase();
    return models.some(m => {
      const modelId = m.guid || m.id;
      return m.name.trim().toLowerCase() === trimmedName && modelId !== excludeId;
    });
  }, [models]);

  const toggleSelectionMode = () => {
    setIsSelectionMode(!isSelectionMode);
    setSelectedIds([]);
  };

  const handleSelectOne = (id) => {
    setSelectedIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  const filteredModels = useMemo(() => {
    return models.filter(m => 
      m.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.company?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.category?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.mainCategory?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [models, searchTerm]);

  const handleBulkDelete = async () => {
    if (!canManage) { 
      showToast("Access Denied", "error"); 
      return; 
    }
    const result = await Swal.fire({
      title: "Are you sure?",
      text: `Delete ${selectedIds.length} models? This action cannot be undone.`,
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#EF4444",
      cancelButtonColor: "#6B7280",
      confirmButtonText: "Yes, delete!",
      cancelButtonText: "No, cancel"
    });

    if (result.isConfirmed) {
      try {
        for (const id of selectedIds) { 
          await printerService.deleteModel(id); 
        }
        Swal.fire({
          title: "Deleted!",
          text: `${selectedIds.length} models have been deleted successfully.`,
          icon: "success",
          confirmButtonColor: "#6366F1",
        });
        onRefresh();
        setSelectedIds([]);
        setIsSelectionMode(false);
      } catch { 
        showToast("Failed to delete some models", "error"); 
      }
    }
  };

  const handleDelete = async (id) => {
    if (!canManage) { 
      showToast("Access Denied", "error"); 
      return; 
    }
    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you want to delete this model? This action cannot be undone.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#EF4444",
      cancelButtonColor: "#6B7280",
      confirmButtonText: "Yes, delete!",
      cancelButtonText: "No, cancel"
    });

    if (result.isConfirmed) {
      try { 
        await printerService.deleteModel(id); 
        Swal.fire({
          title: "Deleted!",
          text: "The model has been deleted successfully.",
          icon: "success",
          confirmButtonColor: "#6366F1",
        });
        onRefresh(); 
      } catch { 
        showToast("Failed to delete model", "error"); 
      }
    }
  };

  const handleEdit = (model, e) => {
    if (e) e.stopPropagation();
    if (!canManage) { 
      showToast("Access Denied", "error"); 
      return; 
    }
    
    setNewModel({
      name: model.name || "",
      company: model.company || "HP",
      mainCategory: model.category === "Computing" ? "PC" : (model.mainCategory || (model.cpu || model.ram || model.ssd ? "PC" : "Printer")),
      category: model.category || "Laser",
      colorType: model.colorType || "Monochrome",
      printerType: model.printerType || "Multi-Function",
      description: model.description || "",
      mrp: model.mrp || "",
      cpu: model.cpu || "",
      ram: model.ram || "",
      ssd: model.ssd || ""
    });
    
    setEditingId(model.guid || model.id);
    setShowAddForm(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCloseForm = () => {
    setShowAddForm(false);
    setEditingId(null);
    setNewModel(initialFormState);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!newModel.name?.trim()) {
      showToast("Model name is required", "error");
      return;
    }
    if (!newModel.company?.trim()) {
      showToast("Company is required", "error");
      return;
    }

    if (isDuplicateModel(newModel.name, editingId)) {
      showToast(`Model "${newModel.name.trim()}" already exists!`, "error");
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const modelData = {
        name: newModel.name.trim(),
        company: newModel.company,
        mainCategory: newModel.mainCategory,
        category: newModel.mainCategory === "Printer" ? newModel.category : "Computing",
        colorType: newModel.mainCategory === "Printer" ? newModel.colorType : "N/A",
        printerType: newModel.mainCategory === "Printer" ? newModel.printerType : "N/A",
        description: newModel.description?.trim() || "",
        mrp: newModel.mrp ? Number(newModel.mrp) : 0,
        cpu: newModel.mainCategory !== "Printer" ? newModel.cpu : null,
        ram: newModel.mainCategory !== "Printer" ? newModel.ram : null,
        ssd: newModel.mainCategory !== "Printer" ? newModel.ssd : null
      };

      if (editingId) {
        await printerService.updateModel(editingId, modelData);
        showToast("Model updated successfully!", "success");
      } else {
        await printerService.addModel(modelData);
        showToast("Model added successfully!", "success");
      }
      
      if (onRefresh) onRefresh();
      handleCloseForm();
    } catch (error) {
      const errorMessage = error.response?.data?.message || error.message || "Failed to save model";
      showToast(errorMessage, "error");
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const getModelDetails = (model) => {
    if (!model) return { serials: [], stock: 0, priceHistory: [], latestPrice: 0, averagePrice: 0 };
    const modelSerials = serials.filter(s => s.modelGuid === model.guid);
    const history = modelSerials
        .filter(s => s.landingPrice > 0)
        .map(s => ({
            price: s.landingPrice,
            date: s.createdAt || new Date().toISOString() 
        }))
        .sort((a,b) => new Date(b.date) - new Date(a.date));
    const inStockItems = modelSerials.filter(s => s.status === "Available");
    const totalValue = inStockItems.reduce((sum, item) => sum + (Number(item.landingPrice) || 0), 0);
    const avgPrice = inStockItems.length > 0 ? Math.round(totalValue / inStockItems.length) : 0;
    return {
      serials: modelSerials,
      stock: inStockItems.length,
      dispatched: modelSerials.filter(s => s.status === "Dispatched").length,
      damaged: modelSerials.filter(s => s.status === "Damaged").length,
      priceHistory: history,
      latestPrice: history[0]?.price || 0,
      averagePrice: avgPrice
    };
  };

  const viewDetails = viewingModel ? getModelDetails(viewingModel) : null;

  const getCompanyColor = (company) => {
    const colors = {
      'HP': { bg: 'from-blue-500 to-blue-600', light: 'bg-blue-50 text-blue-600 border-blue-100' },
      'Canon': { bg: 'from-red-500 to-red-600', light: 'bg-red-50 text-red-600 border-red-100' },
      'Epson': { bg: 'from-indigo-500 to-indigo-600', light: 'bg-indigo-50 text-indigo-600 border-indigo-100' },
      'Brother': { bg: 'from-emerald-500 to-emerald-600', light: 'bg-emerald-50 text-emerald-600 border-emerald-100' },
    };
    return colors[company] || { bg: 'from-slate-500 to-slate-600', light: 'bg-slate-50 text-slate-600 border-slate-100' };
  };

  const getCategoryIcon = (category) => {
    const icons = {
      'Laser': '⚡', 'Inkjet': '💧', 'Ink Tank': '💧', 'Thermal': '🔥', '3D Printer': '🎲',
      'AIO': '🖥️', 'Desktop': '🖱️', 'PC': '💻'
    };
    return icons[category] || '🖨️';
  };

  const nameIsDuplicate = useMemo(() => {
    return isDuplicateModel(newModel.name, editingId);
  }, [newModel.name, editingId, isDuplicateModel]);

  return (
    <div className="space-y-5 relative pb-20 min-h-screen">
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      <div className="relative">
        <div className="absolute -top-4 -left-4 w-48 h-48 bg-gradient-to-br from-indigo-500/10 to-purple-500/10 rounded-full blur-3xl -z-10" />
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="p-1.5 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg shadow-md shadow-indigo-500/25">
                <Box size={14} className="text-white" />
              </div>
              <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">
                {models.length} Models
              </span>
            </div>
            <h1 className="text-xl font-extrabold text-slate-800 tracking-tight">Product Models</h1>
            <p className="text-xs text-slate-500">Manage your product catalog</p>
          </div>

          <div className="flex gap-2 w-full md:w-auto flex-wrap">
            <div className="relative flex-1 md:w-56 min-w-[150px]">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input 
                className="w-full border border-slate-200 pl-9 pr-4 py-2 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none bg-white shadow-sm" 
                placeholder="Search models..." 
                value={searchTerm} 
                onChange={(e) => setSearchTerm(e.target.value)} 
              />
            </div>
            {onRefresh && (
              <button onClick={onRefresh} className="flex items-center gap-1.5 px-3 py-2 bg-white border border-slate-200 text-slate-600 hover:bg-slate-50 rounded-xl text-sm font-medium transition-all shadow-sm">
                <RefreshCw size={14} />
              </button>
            )}
            <button onClick={toggleSelectionMode} className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium transition-all whitespace-nowrap ${isSelectionMode ? "bg-slate-800 text-white shadow-lg" : "bg-white border border-slate-200 text-slate-600 hover:bg-slate-50 shadow-sm"}`}>
              {isSelectionMode ? <X size={14} /> : <CheckSquare size={14} />} 
              <span className="hidden sm:inline">{isSelectionMode ? "Cancel" : "Select"}</span>
            </button>
            {canManage && <button onClick={() => showAddForm ? handleCloseForm() : setShowAddForm(true)} className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium transition-all whitespace-nowrap shadow-sm ${showAddForm ? "bg-slate-100 text-slate-600" : "bg-gradient-to-r from-indigo-500 to-indigo-600 text-white hover:from-indigo-600 hover:to-indigo-700 shadow-indigo-500/25"}`}>
              {showAddForm ? <X size={14} /> : <Plus size={14} />}
              <span className="hidden sm:inline">{showAddForm ? "Close" : "Add Model"}</span>
            </button>}
          </div>
        </div>
      </div>

      {showAddForm && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-lg overflow-hidden animate-in slide-in-from-top duration-300">
          <div className={`bg-gradient-to-r ${editingId ? 'from-amber-500 to-orange-600' : 'from-indigo-500 to-purple-600'} px-5 py-3 flex items-center justify-between`}>
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-white/20 rounded-lg">
                {editingId ? <Edit size={16} className="text-white" /> : <Plus size={16} className="text-white" />}
              </div>
              <h3 className="text-sm font-bold text-white">{editingId ? `Edit Model: ${newModel.name}` : 'Add New Model'}</h3>
            </div>
          </div>
          
          <form onSubmit={handleSubmit} className="p-5">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
              <div className="md:col-span-12 space-y-1.5 pb-2 border-b border-slate-50 mb-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                  <Layers size={10} /> Category *
                </label>
                <div className="flex gap-4 mt-1">
                  {["Printer", "PC"].map((cat) => (
                    <label key={cat} className={`flex items-center gap-2 ${!!editingId ? 'cursor-not-allowed opacity-60' : 'cursor-pointer group'}`}>
                      <input type="radio" name="mainCategory" className={`w-4 h-4 text-indigo-600 border-slate-300 focus:ring-indigo-500 ${!!editingId ? 'cursor-not-allowed' : 'cursor-pointer'}`} checked={newModel.mainCategory === cat} onChange={() => setNewModel({ ...newModel, mainCategory: cat })} disabled={isSubmitting || !!editingId} />
                      <span className={`text-sm font-bold ${newModel.mainCategory === cat ? 'text-indigo-600' : 'text-slate-500 group-hover:text-slate-700'}`}>{cat}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="md:col-span-4 space-y-1.5">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                  <Tag size={10} /> Model Name *
                </label>
                <input className={`w-full border p-2.5 rounded-xl text-sm bg-slate-50 focus:bg-white focus:ring-2 outline-none transition-all ${nameIsDuplicate ? 'border-red-400 focus:ring-red-500' : 'border-slate-200 focus:ring-indigo-500'}`} placeholder="e.g. LaserJet Pro M1136" value={newModel.name} onChange={(e) => setNewModel({ ...newModel, name: e.target.value })} required disabled={isSubmitting} />
              </div>
              
              <div className="md:col-span-3 space-y-1.5">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                  <Building2 size={10} /> Company *
                </label>
                <MasterDropdown 
                  code="COMPANY" 
                  placeholder="Select Company" 
                  value={newModel.company} 
                  onChange={(e) => setNewModel({ ...newModel, company: e.target.value })} 
                  disabled={isSubmitting} 
                />
              </div>

              <div className="md:col-span-2 space-y-1.5">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider"><span>₹</span> MRP</label>
                <input type="number" className="w-full border border-slate-200 p-2.5 rounded-xl text-sm bg-slate-50 focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none transition-all" placeholder="15000" value={newModel.mrp} onChange={(e) => setNewModel({ ...newModel, mrp: e.target.value })} disabled={isSubmitting} min="0" />
              </div>

              {newModel.mainCategory === "Printer" ? (
                <>
                  <div className="md:col-span-3 space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1"><Layers size={10} /> Printer Category</label>
                    <MasterDropdown 
                      code="PRINTER_CAT" 
                      placeholder="Select Category" 
                      value={newModel.category} 
                      onChange={(e) => setNewModel({ ...newModel, category: e.target.value })} 
                      disabled={isSubmitting} 
                    />
                  </div>
                  <div className="md:col-span-3 space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1"><Palette size={10} /> Color Type</label>
                    <MasterDropdown 
                      code="COLOR_TYPE" 
                      placeholder="Select Color Type" 
                      value={newModel.colorType} 
                      onChange={(e) => setNewModel({ ...newModel, colorType: e.target.value })} 
                      disabled={isSubmitting} 
                    />
                  </div>
                  <div className="md:col-span-3 space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1"><Settings2 size={10} /> Printer Type</label>
                    <MasterDropdown 
                      code="PRINTER_TYPE" 
                      placeholder="Select Printer Type" 
                      value={newModel.printerType} 
                      onChange={(e) => setNewModel({ ...newModel, printerType: e.target.value })} 
                      disabled={isSubmitting} 
                    />
                  </div>
                </>
              ) : (
                <>
                  <div className="md:col-span-3 space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">CPU *</label>
                    <input className="w-full border border-slate-200 p-2.5 rounded-xl text-sm bg-slate-50 focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="e.g. Core i5 12th Gen" value={newModel.cpu} onChange={(e) => setNewModel({ ...newModel, cpu: e.target.value })} required={newModel.mainCategory !== "Printer"} disabled={isSubmitting} />
                  </div>
                  <div className="md:col-span-3 space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">RAM *</label>
                    <input className="w-full border border-slate-200 p-2.5 rounded-xl text-sm bg-slate-50 focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="e.g. 8GB DDR4" value={newModel.ram} onChange={(e) => setNewModel({ ...newModel, ram: e.target.value })} required={newModel.mainCategory !== "Printer"} disabled={isSubmitting} />
                  </div>
                  <div className="md:col-span-3 space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">SSD/HDD *</label>
                    <input className="w-full border border-slate-200 p-2.5 rounded-xl text-sm bg-slate-50 focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="e.g. 512GB NVMe" value={newModel.ssd} onChange={(e) => setNewModel({ ...newModel, ssd: e.target.value })} required={newModel.mainCategory !== "Printer"} disabled={isSubmitting} />
                  </div>
                </>
              )}
              <div className="md:col-span-12 space-y-1.5">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1"><Info size={10} /> Description</label>
                <textarea className="w-full border border-slate-200 p-2.5 rounded-xl text-sm bg-slate-50 focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none min-h-[80px]" placeholder="Optional details..." value={newModel.description} onChange={(e) => setNewModel({ ...newModel, description: e.target.value })} disabled={isSubmitting}></textarea>
              </div>
            </div>
            
            <div className="flex justify-between items-center mt-4 pt-4 border-t border-slate-100">
              <div className="text-xs text-slate-400">{editingId ? `Editing model ID: ${editingId}` : "Fill in the required fields"}</div>
              <div className="flex gap-2">
                <button type="button" onClick={handleCloseForm} disabled={isSubmitting} className="px-4 py-2 text-sm text-slate-600 hover:bg-slate-100 rounded-xl">Cancel</button>
                <button type="submit" disabled={isSubmitting || nameIsDuplicate} className={`text-white px-5 py-2 rounded-xl text-sm font-medium flex items-center gap-2 shadow-lg ${editingId ? "bg-amber-500" : "bg-indigo-600"}`}>
                  {isSubmitting ? <Loader2 size={14} className="animate-spin" /> : (editingId ? <Edit size={14} /> : <Sparkles size={14} />)}
                  {editingId ? "Update Model" : "Add Model"}
                </button>
              </div>
            </div>
          </form>
        </div>
      )}

      {filteredModels.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center">
          <Package size={48} className="text-slate-200 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-slate-700">No Models Found</h3>
          <p className="text-sm text-slate-500">Start by adding your first product model</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredModels.map((m, index) => {
            const modelId = m.guid || m.id || index;
            const isSelected = selectedIds.includes(modelId);
            const details = getModelDetails(m);
            const companyColor = getCompanyColor(m.company);
            return (
              <div key={modelId} onClick={() => isSelectionMode ? handleSelectOne(modelId) : setViewingModel(m)} className={`group bg-white rounded-xl border transition-all cursor-pointer overflow-hidden ${isSelected ? 'border-indigo-500 ring-2 ring-indigo-100 shadow-lg' : 'border-slate-200 shadow-sm hover:shadow-md'}`}>
                <div className={`h-1 bg-gradient-to-r ${companyColor.bg}`}></div>
                <div className="p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-bold text-slate-800 text-sm truncate">{m.name}</h3>
                    {canManage && !isSelectionMode && (
                      <div className="flex gap-1 opacity-0 group-hover:opacity-100">
                        <button onClick={(e) => handleEdit(m, e)} className="p-1 text-amber-500 hover:bg-amber-50 rounded"><Edit size={12} /></button>
                        <button onClick={(e) => { e.stopPropagation(); handleDelete(modelId); }} className="p-1 text-red-500 hover:bg-red-50 rounded"><Trash2 size={12} /></button>
                      </div>
                    )}
                  </div>
                  <div className="flex flex-wrap gap-1 mb-2">
                    <span className="px-1.5 py-0.5 text-[8px] bg-slate-100 text-slate-600 rounded font-bold uppercase">{m.mainCategory}</span>
                    <span className={`px-1.5 py-0.5 text-[8px] rounded font-bold uppercase ${companyColor.light}`}>{m.company}</span>
                    {m.mainCategory === 'Printer' ? (
                      <span className="px-1.5 py-0.5 text-[8px] bg-blue-50 text-blue-600 rounded font-bold uppercase">{m.category}</span>
                    ) : (
                      <span className="px-1.5 py-0.5 text-[8px] bg-indigo-50 text-indigo-600 rounded font-bold uppercase">{m.cpu || 'PC'}</span>
                    )}
                  </div>
                  <div className="flex justify-between items-center text-[10px] text-slate-400 mt-4 pt-3 border-t">
                    <span>Stock: <span className="font-bold text-slate-700">{details.stock}</span></span>
                    <span className={`px-2 py-0.5 rounded-full font-bold ${details.stock > 0 ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100'}`}>
                      {details.stock > 0 ? 'In Stock' : 'Out'}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {viewingModel && viewDetails && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4" onClick={() => setViewingModel(null)}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[85vh]" onClick={(e) => e.stopPropagation()}>
            <div className={`bg-gradient-to-r ${getCompanyColor(viewingModel.company).bg} p-4 text-white`}>
              <div className="flex justify-between items-start">
                <h3 className="font-bold text-lg">{viewingModel.name}</h3>
                <button onClick={() => setViewingModel(null)}><X size={18} /></button>
              </div>
              <p className="text-white/80 text-xs mt-1">{viewingModel.company} • {viewingModel.mainCategory}</p>
            </div>
            <div className="p-4 space-y-4 overflow-y-auto">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Specs</p>
                  <p className="text-sm text-slate-700 mt-1">
                    {viewingModel.mainCategory === 'Printer' ? 
                      `${viewingModel.category} | ${viewingModel.colorType}` : 
                      `${viewingModel.cpu} | ${viewingModel.ram} | ${viewingModel.ssd}`}
                  </p>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <p className="text-[10px] text-slate-400 font-bold uppercase">MRP</p>
                  <p className="text-sm font-bold text-slate-700 mt-1">₹{Number(viewingModel.mrp || 0).toLocaleString()}</p>
                </div>
              </div>
              {viewingModel.description && <div className="bg-slate-50 p-3 rounded-xl text-xs text-slate-600">{viewingModel.description}</div>}
              <div className="flex justify-between items-center pt-4 border-t">
                <div className="text-center">
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Available</p>
                  <p className="text-lg font-bold text-emerald-600">{viewDetails.stock}</p>
                </div>
                <div className="text-center">
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Total Serials</p>
                  <p className="text-lg font-bold text-slate-700">{viewDetails.serials.length}</p>
                </div>
                <div className="text-center">
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Latest Landing Price</p>
                  <p className="text-lg font-bold text-indigo-600">₹{Number(viewDetails.latestPrice).toLocaleString()}</p>
                </div>
              </div>
            </div>
            <div className="p-4 bg-slate-50 border-t flex justify-end gap-2">
              {canManage && <button onClick={() => { handleEdit(viewingModel); setViewingModel(null); }} className="px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm font-medium text-amber-600">Edit</button>}
              <button onClick={() => setViewingModel(null)} className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-sm font-medium">Close</button>
            </div>
          </div>
        </div>
      )}

      {selectedIds.length > 0 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-slate-900 text-white px-5 py-2.5 rounded-full shadow-2xl flex items-center gap-4 z-50">
          <span className="text-xs font-bold">{selectedIds.length} Selected</span>
          <button onClick={handleBulkDelete} disabled={!canManage} className="text-xs text-red-400 font-bold">Delete</button>
          <button onClick={() => { setSelectedIds([]); setIsSelectionMode(false); }} className="text-slate-400"><X size={16} /></button>
        </div>
      )}
    </div>
  );
}
